<?php get_header();?>

<div id="wrapper">
   <div class="lal"></div>
   <?php require_once("navi.php");?>
   <!-- id header -->
   <div id="main">
      <div class="stm_single_post">
         <div class="entry-header clearfix" style="background-color: #eab830;">
            <div class="container">
               <div class="entry-title-left">
                  <div class="entry-title">
                     <h2 class="h1" style="color: #ffffff;">Blog làm đẹp</h2>
                     <div class="sub_title h3" style="color: #ffffff;">Blog post subtitle</div>
                     <div class="stm_colored_separator">
                        <div class="triangled_colored_separator" style="background-color:#ffffff; ">
                           <div class="triangle" style="border-bottom-color:#ffffff;"></div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="entry-title-right"></div>
               <style type="text/css">.entry-header .entry-title h1.h2:before {
                  background: #ffffff;
                  }
               </style>
            </div>
         </div>
         <!-- Breads -->
         <div class="stm_lms_breadcrumbs stm_lms_breadcrumbs__header_2">
            <div class="breadcrumbs_holder"></div>
         </div>
         <article id="" class=" post type-post status-publish format-standard has-post-thumbnail hentry category-skin-care tag-lam-dep tag-lao-hoa tag-thoi-quen">
            <div class="container">
               <div class="vc_row wpb_row vc_row-fluid">
                  <div class="wpb_column vc_column_container vc_col-sm-12">
                     <div class="vc_column-inner">
                        <div class="wpb_wrapper">
                           <div class="stm_post_unit stm_post_unit_vc vc_custom_1437111129257">
                              <div class="stm_post_info">
                                 <h1 class="h2 post_title"><?php the_title(); ?></h1>
                                 <div class="stm_post_details clearfix">
                                    <ul class="clearfix post_meta">
                                       <li class="post_date h6"><i class="far fa-clock"></i><span><?php echo get_the_date('j/m/Y'); ?></span></li>
                                       <li class="post_by h6"><i class="fa fa-user"></i>Posted by: <span><?php the_author();?></span></li>
                                       <li class="post_cat h6"><i class="fa fa-flag"></i> Category: <?php
                                    $catList = '';
                                    foreach((get_the_category()) as $cat) {
                                       $catID = get_cat_ID( $cat->cat_name );
                                       $catLink = get_category_link( $catID );
                                       if(!empty($catList)) {
                                          $catList .= '<span class="post_list_divider">,&nbsp;</span>';
                                       }
                                       $catList .= '<a href="'.$catLink.'">'.$cat->cat_name.'</a>';
                                    }
                                    echo $catList;
                                    ?></li>
                                    </ul>
                                    <div class="comments_num"> <a href="#respond" class="post_comments h6"><i class="fa fa-comments-o"></i> No Comments </a></div>
                                 </div>
                                 <div class="post_thumbnail">
                                    <img width="1170" height="500" src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full') ?>" data-src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full') ?>" class="img-responsive wp-post-image wp-stateless-item lazyloaded" alt="" data-image-size="img-1170-500" data-stateless-media-bucket="rebloom-media-bucket"  /></noscript>
                                 </div>
                              </div>
                           </div>

                           <?php 
                            if ( have_posts() ) : 
                                while ( have_posts() ) : the_post(); ?>

                                <?php the_content();?>    

                            <?php endwhile; 
                                endif; 
                            ?>   
                        </div>


                     </div>



                  </div>


               </div>


<div class="vc_row wpb_row vc_inner vc_row-fluid">
   <div class="wpb_column vc_column_container vc_col-sm-6">
      <div class="vc_column-inner">
         <div class="wpb_wrapper">
            <div class="stm_post_tags widget_tag_cloud">
               <div class="tagcloud"> <?php 
                                 $my_tags = get_the_tags();
                                 if ( $my_tags ) {
                                       foreach ( $my_tags as $tag ) {
                                          $tag_names[] = '<a href="' . get_tag_link($tag->term_id) . '" title="' . $title . '">' .$tag->name.'</a>';
                                       }
                                       echo  implode( ' ', $tag_names );
                                 }
                                 ?></div>
            </div>
         </div>
      </div>
   </div>
   <div class="wpb_column vc_column_container vc_col-sm-6">
      <div class="vc_column-inner">
         <div class="wpb_wrapper">
            <div class="pull-right xs-pull-left">
               <div class="stm_share">
                  <div class="mo-openid-app-icons circle ">
                     <p style="margin-top:4% !important; margin-bottom:0px !important; color:#000000">Chia sẻ:</p>
                     <div class="horizontal">
                        <a rel="nofollow" title="Facebook" onclick="popupCenter(&quot;https://www.facebook.com/dialog/share?app_id=766555246789034&amp;display=popup&amp;href=https://rebloom.world/magazine/top-5-sua-rua-mat-chieu-chuong-da-moi-sang/&quot;, 800, 400);" class="mo-openid-share-link" style="margin-left : 4px !important"><img alt="Facebook" style="height: 35px !important;width: 35px !important;" src="https://rebloom.world/wp-content/plugins/miniorange-login-openid/includes/images/icons/facebook.png" class="mo-openid-app-share-icons oval"></a>
                        <span2 style="margin-left : 4px !important"></span2>
                        <a rel="nofollow" title="Twitter" onclick="popupCenter(&quot;https://twitter.com/intent/tweet?text=Top%205%20s%E1%BB%AFa%20r%E1%BB%ADa%20m%E1%BA%B7t%20chi%E1%BB%81u%20chu%E1%BB%99ng%20da%20m%E1%BB%97i%20s%C3%A1ng&amp;url=https://rebloom.world/magazine/top-5-sua-rua-mat-chieu-chuong-da-moi-sang/&quot;, 600, 300);" class="mo-openid-share-link" style="margin-left : 4px !important"><img alt="Twitter" style="height: 35px !important;width: 35px !important;" src="https://rebloom.world/wp-content/plugins/miniorange-login-openid/includes/images/icons/twitter.png" class="mo-openid-app-share-icons oval"></a><a rel="nofollow" title="Google" onclick="popupCenter(&quot;https://plus.google.com/share?url=https://rebloom.world/magazine/top-5-sua-rua-mat-chieu-chuong-da-moi-sang/&quot;, 800, 500);" class="mo-openid-share-link" style="margin-left : 4px !important"><img alt="Google" style="height: 35px !important;width: 35px !important;background-color: oval" src="https://rebloom.world/wp-content/plugins/miniorange-login-openid/includes/images/icons/google.png" class="mo-openid-app-share-icons oval"></a><a rel="nofollow" title="Pinterest" href="javascript:pinIt();" class="mo-openid-share-link" style="margin-left : 4px !important"><img alt="Pinterest" style="height: 35px !important;width: 35px !important;" src="https://rebloom.world/wp-content/plugins/miniorange-login-openid/includes/images/icons/pinterest.png" class="mo-openid-app-share-icons oval"></a>
                     </div>
                  </div>
                  <br> 
               </div>
            </div>
         </div>
      </div>
   </div>
</div>



               <div id="jp-relatedposts" class="jp-relatedposts" style="display: block;">
                  <h3 class="jp-relatedposts-headline"><em>Bài khác liên quan</em></h3>
                  <div class="jp-relatedposts-items jp-relatedposts-items-visual jp-relatedposts-grid ">
    

                    <?php $categories = get_the_category($post->ID); ?>
                    <?php if ($categories): ?>
                    <?php $category_ids = array(); ?>
                    <?php foreach($categories as $individual_category) : ?>
                    <?php $category_ids[] = $individual_category->term_id; ?>
                    <?php endforeach; ?>
                    <?php $args=array(
                    'category__in' => $category_ids,
                    'post__not_in' => array($post->ID),
                    'posts_per_page'=>3,
                    'ignore_sticky_posts'=>1,
                    'oderby' => 'rand'
                    );?>
                    <?php $my_query = new WP_Query($args); ?>
                    <?php if( $my_query->have_posts() ) : ?>

                    <?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
                    <div class="jp-relatedposts-post jp-relatedposts-post0 jp-relatedposts-post-thumbs" data-post-id="<?php echo get_the_ID()?>" data-post-format="false">
                    <a href="<?php the_permalink();?>">
                            <img width="1170" height="500" src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full') ?>" data-src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full') ?>" class="mb-3 wp-post-image wp-stateless-item lazyload" alt="" sizes="(max-width: 1170px) 100vw, 1170px" data-image-size="post-thumbnail" data-stateless-media-bucket="rebloom-media-bucket" data-stateless-media-name="" />
                            <noscript><img width="1170" height="500" src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full') ?>" class="mb-3 wp-post-image wp-stateless-item lazyload" alt="" sizes="(max-width: 1170px) 100vw, 1170px" data-image-size="post-thumbnail" data-stateless-media-bucket="rebloom-media-bucket" data-stateless-media-name="" /></noscript>
                        </a>
                        <a class="post_list_item_title h3" href="<?php the_permalink();?>"><?php the_title();?></a>
                        <p class="post_list_item_excerpt mt-3"><?php echo get_the_excerpt();?></p>
                        <br/>
                        <p class="jp-relatedposts-post-context related_tag">In &nbsp; 
                            <?php
                                    $catList = '';
                                    foreach((get_the_category()) as $cat) {
                                       $catID = get_cat_ID( $cat->cat_name );
                                       $catLink = get_category_link( $catID );
                                       if(!empty($catList)) {
                                          $catList .= '<span class="post_list_divider">, &nbsp;</span>';
                                       }
                                       $catList .= '<a href="'.$catLink.'">'.$cat->cat_name.'</a>';
                                    }
                                    echo $catList;
                                    ?>
                        </p>
                        </div>
                    <?php endwhile;?>

                    <?php endif; ?>
                    <?php wp_reset_query();?>
                    <?php endif; ?>
                     
                     
                     
                  </div>
               </div>
            </div>
         </article>
      </div>
   </div>
</div>

<?php get_footer();?>