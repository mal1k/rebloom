<?php if ( ! defined( 'ABSPATH' ) ) exit; //Exit if accessed directly
STM_LMS_Course::course_views(get_the_ID()); ?>
<?php get_header(); ?>
<?php require_once("navi.php");?>
<div id="main">
	<div class="<?php echo apply_filters('stm_lms_wrapper_classes', 'stm-lms-wrapper'); ?>">
		<div class="container">
			<?php if(have_posts()): ?>
				<?php while(have_posts()): the_post();  ?>
					<?php do_action('stm-lms-content-' . get_post_type()); ?>
				<?php endwhile; ?>
			<?php endif; ?>
		</div>
	</div>
</div>

<?php get_footer(); ?>