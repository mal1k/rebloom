<?php  require $_SERVER['DOCUMENT_ROOT'].'/wp-content/themes/masterstudy-child/navi.php' ;?>
