<div class="stm_lms_courses__single--title">
	<a href="<?php the_permalink(); ?>">
		<h5><?php the_title(); ?></h5>
	</a>
</div>