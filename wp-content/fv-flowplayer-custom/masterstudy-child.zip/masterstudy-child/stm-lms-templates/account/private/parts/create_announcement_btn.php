<?php
/**
 * @var $current_user
 */

do_action('stm_lms_create_announcement_btn', $current_user);