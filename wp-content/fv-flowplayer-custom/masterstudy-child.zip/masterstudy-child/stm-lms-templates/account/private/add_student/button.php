<div class="stm-lms-user_create_announcement_btn">
    <a href="<?php echo esc_url(STM_LMS_Instructor::instructor_add_students_url()) ?>">
        <i class="fa fa-user-plus"></i>
        <span><?php esc_html_e('Add student', 'masterstudy-lms-learning-management-system') ?></span>
    </a>
</div>