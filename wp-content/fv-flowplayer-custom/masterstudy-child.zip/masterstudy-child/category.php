<?php get_header(); ?>

<div id="wrapper">
   <div class="lal"></div>
   <?php require_once("navi.php");?>
   <!-- id header -->
   <div id="main">
      <!-- Title -->
      <div class="entry-header clearfix" style="background-color: #4ed7a8;">
         <div class="container">
            <div class="entry-title-left">
               <div class="entry-title">
                  <h1 style="">Blog làm đẹp</h1>
               </div>
            </div>
            <div class="entry-title-right"></div>
         </div>
      </div>
      <!-- Breads -->
      <!--<div class="stm_lms_breadcrumbs stm_lms_breadcrumbs__header_2">
         <div class="breadcrumbs_holder_empty"></div>
      </div>-->
      <div class="container blog_main_layout_grid">
         <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
               <div class="blog_layout_grid sidebar_position_right">
                  <div class="row">
                    <!-- loop start block --> 
                    <?php 
                     if ( have_posts() ) : 
                        while ( have_posts() ) : the_post(); ?>
                     <div class="col-md-6 col-sm-6 col-xs-12 blog-cols-sidebar plugin_style">
                        <div class="post_list_content_unit">
                           <div>
                              <div class="post_list_featured_image">
                                 <a href="<?php the_permalink();?>" title="Watch full">
                                    <img width="370" height="193" src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full') ?>" data-src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full') ?>" class="img-responsive wp-post-image wp-stateless-item ls-is-cached lazyloaded" alt="" data-image-size="img-370-193" data-stateless-media-bucket="rebloom-media-bucket" data-stateless-media-name="2020/07/764a18c3-oils-cover.jpg">
                                    <noscript><img width="370" height="193" src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full') ?>" class="img-responsive wp-post-image wp-stateless-item lazyload" alt="" data-image-size="img-370-193" data-stateless-media-bucket="rebloom-media-bucket" data-stateless-media-name="2020/07/764a18c3-oils-cover.jpg" /></noscript>
                                 </a>
                              </div>
                           </div>
                           <div class="post_list_inner_content_unit post_list_inner_content_unit_left">
                              <a href="<?php the_permalink();?>" class="post_list_item_title h3"><?php the_title();?></a>
                              <div class="clearfix">
                                 <div class="post_list_meta_unit">
                                    <div class="date-d"><?php echo get_the_date('j'); ?></div>
                                    <div class="date-m date-m-plugin"><?php echo get_the_date('M'); ?></div>
                                 </div>
                              </div>
                              <div class="post_list_item_excerpt">
                                 <p><?php the_excerpt();?></p>
                              </div>
                              <div class="short_separator"></div>
                              <!-- Post cats -->
                              <div class="post_list_cats">
                                 <span class="post_list_cats_label">Posted in:</span>
                                 <?php
                                    $catList = '';
                                    foreach((get_the_category()) as $cat) {
                                       $catID = get_cat_ID( $cat->cat_name );
                                       $catLink = get_category_link( $catID );
                                       if(!empty($catList)) {
                                          $catList .= '<span class="post_list_divider">, </span>';
                                       }
                                       $catList .= '<a href="'.$catLink.'">'.$cat->cat_name.'</a>';
                                    }
                                    echo $catList;
                                    ?>
                              </div>
                              </span>

                              <div class="post_list_item_tags"> <span class="post_list_tags_label">Tags:</span>
                               <?php 
                                 $my_tags = get_the_tags();
                                 if ( $my_tags ) {
                                       foreach ( $my_tags as $tag ) {
                                          $tag_names[] = '<a href="' . get_tag_link($tag->term_id) . '" title="' . $title . '">' .$tag->name.'</a>';
                                       }
                                       echo  implode( ', ', $tag_names );
                                 }
                                 ?>
                              </div>
                           </div>
                           <!-- post_list_inner_content_unit -->
                        </div>
                        <!-- post_list_content_unit -->
                     </div>
                     <!-- end loop block -->
                     <?php endwhile; 
                        endif; 
                     ?>
                  </div>
               </div>
               <!-- blog_layout -->
            </div>
            <div class="col-lg-3 col-md-3 hidden-sm hidden-xs">
               <div class="sidebar-area sidebar-area-right">
                  <aside id="search-2" class="widget widget_search">
                     <div class="widget_title">
                        <h3>TÌM KIẾM</h3>
                     </div>
                     <form role="search" method="get" class="search-form" action="<?php bloginfo('url'); ?>"> <label> <span class="screen-reader-text">Search for:</span> <input type="search" class="search-field" placeholder="Search …" value="" name="s"> </label> <input type="submit" class="search-submit" value="Search"></form>
                  </aside>
                  <aside id="tag_cloud-2" class="widget widget_tag_cloud">
                     <div class="widget_title">
                        <h3>TỪ KHÓA</h3>
                     </div>
                     <div class="tagcloud">
                        <?php 
                           $tags = get_tags(array(
                           'hide_empty' => false
                           ));
                           $i = 1;
                           foreach ($tags as $tag) {
                           echo '<a href="'.get_tag_link($tag->term_id).'" class="tag-cloud-link tag-link-'.$tag->term_id.' tag-link-position-'.$i.'">' . $tag->name . '</a>';
                           $i++;    
                           }
                           ?>
                    </div>
                  </aside>

                  <aside id="custom_html-2" class="widget_text widget widget_custom_html">
                     <div class="widget_title">
                        <h3>VỀ KHÓA HỌC REBLOOM</h3>
                     </div>
                     <?php if ( is_active_sidebar( 'blog-side-bar' ) ) : ?>
                                    <?php dynamic_sidebar( 'blog-side-bar' ); ?>
                                <?php endif; ?>
                  </aside>
                  <aside id="custom_html-8" class="widget_text widget widget_custom_html">
                     <div class="textwidget custom-html-widget"><a class="about-course__link" href="<?php echo home_url();?> ">THÔNG TIN KHÓA HỌC</a></div>
                  </aside>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<?php get_footer();?>