<?php
/**
 * @version 3.0.0
 */
?>
			<div class="wp-embed-footer">
				<?php the_embed_site_title() ?>

				<div class="wp-embed-meta">
					<?php
					/** This action is documented in wp-includes/theme-compat/embed-content.php */
					do_action( 'embed_content_meta'); ?>
				</div>
			</div>
