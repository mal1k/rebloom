<footer id="footer">
         <div class="footer_wrapper ">
            <div id="footer_bottom">
               <div class="footer_widgets_wrapper kek text-upper">
                  <div class="container">
                     <div class="widgets cols_4 clearfix">
                        <aside id="custom_html-4" class="widget_text widget widget_custom_html">
                           <div class="textwidget custom-html-widget">
                              <img src="<?php echo get_stylesheet_directory_uri();?>/img/c4deb285-logo-footer.svg"
                                 style="width:150px;">
                              <?php if ( is_active_sidebar( 'footer-side-bar' ) ) : ?>
                                    <?php dynamic_sidebar( 'footer-side-bar' ); ?>
                                <?php endif; ?>
                              <div class="footer-copyright">
                                 <p>Copyright© 2019 ReBloom <?php echo date('Y');?></p>
                              </div>
                              <a href="#" target="_blank"><img src="<?php echo get_stylesheet_directory_uri();?>/img/gov_sticker.png"></a>
                           </div>
                        </aside>
                        <aside id="custom_html-3" class="widget_text widget widget_custom_html">
                           <div class="widget_title">
                              <h3>TRANG</h3>
                           </div>
                           <div class="textwidget custom-html-widget">

                           <?php if( $menu_items = wp_get_nav_menu_items('Footer 1') ) { // "Меню для шапки" - это название моего меню. Вы можете также использовать ID или ярлык
                                    $menu_list = '';
                                    foreach ( (array) $menu_items as $key => $menu_item ) {
                                        $title = $menu_item->title; // заголовок элемента меню (анкор ссылки)
                                        $url = $menu_item->url; // URL ссылки
                                        $menu_list .= '<p> <a class="links-footer" href="' . $url . '">' . $title . '</a></p> ';
                                    }
                                    echo $menu_list;
                                }?>
                           </div>
                        </aside>
                        <aside id="custom_html-7" class="widget_text widget widget_custom_html">
                           <div class="textwidget custom-html-widget">
                              <div class="footer-contacts flex-col">
                                 <div class="footer-mail">
                                    <h5>LIÊN HỆ</h5>
                                    <p style="display: flex; align-items: center;"><img src="<?php echo get_stylesheet_directory_uri();?>/img/b183cf8e-email.svg"
                                       class="custom-logo" alt="Email"><a
                                       href="mailto:info@rebloom.vn">info@rebloom.vn</a></p>
                                 </div>
                                 <div class="footer-social-links flex-col">
                                    <h5>MẠNG XÃ HỘI</h5>
                                    <div> <a href="https://www.instagram.com/rebloom.vietnam"><img
                                       src="<?php echo get_stylesheet_directory_uri();?>/img/69f7f0af-insta.svg"
                                       alt="Instagram"></a> <a href="https://www.facebook.com/rebloomvietnam"><img
                                       src="<?php echo get_stylesheet_directory_uri();?>/img/cca25910-fb.svg"
                                       alt="Facebook"></a> <a href="https://www.youtube.com/channel/UCK7E024yhmMHaiQCJCW7u9Q"> <img src="<?php echo get_stylesheet_directory_uri();?>/img/eaf5cfe2-youtube.svg" alt="Youtube"></a></div>
                                 </div>
                              </div>
                           </div>
                        </aside>
                        <aside id="custom_html-6" class="widget_text widget widget_custom_html">
                           <div class="textwidget custom-html-widget">
                              <div class="footer-contacts">
                                 <h5> BÀI HỌC</h5>
                              </div>
                              <p> <a class="links-footer" href="#"> Khóa học dành cho Đường cười </a></p>
                              <p> <a class="links-footer" href="#"> Khóa học tạo hình V-line </a></p>
                              <p> <a class="links-footer" href="#"> Khóa học dành cho Vùng trán </a></p>
                              <p> <a class="links-footer" href="#"> Khóa học ReBloom Trọn bộ </a></p>
                              <div class="footer-blog">
                                 <a href="<?php the_permalink(45)?>">
                                    <h5>Tạp chí <img src="<?php echo get_stylesheet_directory_uri();?>/img/349e1a88-arrow.svg"
                                       class="custom-logo" alt="Arrow"></h5>
                                 </a>
                              </div>
                           </div>
                        </aside>
                        <div class="top-slice-arrow"> <a href="#" class="top-slice-arrow-a" style="opacity: 1;"></a></div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Pop-up before go to cart -->
            <div class="buy-popup__wrapper">
               <div class="buy-popup__background"></div>
               <div class="buy-popup__main">
                  <img src="<?php echo get_stylesheet_directory_uri();?>/img/Course-Cover.png">
                  <div class="buy-popup__text">
                     <h5>Khóa học Trẻ Hóa Sâu ReBloom</h5>
                     <p>Khóa học Trẻ Hóa Sâu ReBloom bao gồm:</p>
                     <ul>
                        <li>- Tài khoản cá nhân cho học viên</li>
                        <li>- Quyền truy cập trọn bộ 30 video bài học online</li>
                        <li>- Phụ đề và lồng tiếng Việt</li>
                        <li>- Hỗ trợ kĩ thuật</li>
                     </ul>
                     <div class="buy-popup__button"> <span>2.100.000 VND</span> <a href='#' class='text-center btn btn-default btn-checkout' style="font-weight: 500;">Go to cart and pay</a></div>
                  </div>
               </div>
            </div>
            <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri();?>/css/jquery-ui.css">
         </div>

      </footer>
      <!-- Searchform -->
      <div class="modal fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchModal">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-body heading_font">
                  <div class="search-title">Search</div>
                  <form role="search" method="get" id="searchform" action="<?php home_url();?>">
                     <div class="search-wrapper"> <input placeholder="Start typing here..." type="text" class="form-control search-input" value="" name="s" id="s" /> <button type="submit" class="search-submit" ><i class="fa fa-search"></i></button></div>
                  </form>
               </div>
            </div>
         </div>
      </div>

     
      <link rel='stylesheet' id='stm-header_mobile-account-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/themes/masterstudy/assets/css/vc_modules/header_mobile/account.css' type='text/css' media='all' />
      <link rel='stylesheet' id='stm-lms-login-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/uploads/stm_lms_styles/parts/login.css' type='text/css' media='all' />
      <link rel='stylesheet' id='stm-lms-register-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/uploads/stm_lms_styles/parts/register.css' type='text/css' media='all' />
      
      <link rel='stylesheet' id='stm-vue-autocomplete-vue2-autocomplete-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/themes/masterstudy/assets/css/vc_modules/vue-autocomplete/vue2-autocomplete.css' type='text/css' media='all' />
      <link rel='stylesheet' id='stm-lms-enterprise-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/uploads/stm_lms_styles/parts/enterprise.css' type='text/css' media='all' />
      <link rel='stylesheet' id='stm-lms-user-courses-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/uploads/stm_lms_styles/parts/user-courses.css' type='text/css' media='all' />
      <link rel='stylesheet' id='stm-lms-instructor_courses-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/uploads/stm_lms_styles/parts/instructor_courses.css' type='text/css' media='all' />
      <link rel='stylesheet' id='fv_flowplayer-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/fv-flowplayer-custom/style-1.css' type='text/css' media='all' />
      
      <div class="activate-pop-up">
         <div class="activate-pop-up__layout"></div>
         <div class="activate-pop-up__container">
            <label for="license_key" style="color:#000;">Activation key</label> <input class="form-control" type="text" id="license_key" placeholder="Enter activation key"> <button id="activate" class="btn btn-default text-center">Activate</button>
            <div class="active-pop-up__message"></div>
         </div>
      </div>
      <?php wp_footer();?>
   </body>
   <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
   
     
   <script type='text/javascript' src='<?php echo get_stylesheet_directory_uri();?>/js/lib.js'></script>

   <script>
         (function ($) {

$(window).load(function () {
    stm_lms_login(true);
});

})(jQuery);

function stm_lms_login(redirect) {
var $ = jQuery;
$('.stm-lms-login:not(.loaded)').each(function () {
    let $this = $(this);
    $(this).addClass('loaded');
    var vue_obj = {
        el: this,
        data: function () {
            return {
                vue_loaded: true,
                loading: false,
                login: '',
                password: '',
                activation_key: '',
                message: '',
                status: '',
                site_key: '',
                recaptcha: '',
                captcha_error: '',
                open_lost_password: false,
                lost_password: '',
                lost_password_process: '',
            }
        },
        methods: {
            logIn() {
                var vm = this;
                vm.loading = true;
                vm.message = '';
                var data = {
                    'user_login': vm.login,
                    'user_password': vm.password,
                };




                if (vm.site_key && typeof grecaptcha !== 'undefined') {
                    grecaptcha.ready(function () {
                        grecaptcha.execute(vm.site_key, {
                            action: 'login'
                        }).then(function (token) {
                            data['recaptcha'] = token;
                            vm.processLogin(data);
                        });
                    });
                } else {
                    vm.processLogin(data);
                }


            },
            processLogin(data) {
                var vm = this;
                var activation_data = {
                    'license_key': vm.activation_key
                };

                if (window.location.pathname == '/activate/') {
                    if (vm.activation_key != '') {
                        vm.$http.post(stm_lms_ajaxurl + '?action=stm_lms_login&nonce=' + stm_lms_nonces['stm_lms_login'], data).then(function (response) {

                            vm.$http.post(stm_lms_ajaxurl + '?action=account_activate', activation_data).then(function (r) {
                                console.log(r.body['message']);

                                vm.message = response.body['message'];
                                vm.status = response.body['status'];
                                vm.loading = false;


                                if (r.body['status'] == 'success') {
                                    vm.message = 'Account activated successfully. Redirecting...';
                                    if (response.body['user_page']) {
                                        if (redirect) {
                                            window.location = response.body['user_page'];
                                        } else {
                                            location.reload();
                                        }
                                    }
                                } else {
                                    vm.$http.post(stm_lms_ajaxurl + '?action=stm_lms_logout');
                                    vm.message = r.body['message'];
                                    vm.status = 'error';
                                    vm.loading = false;
                                }
                            })
                        })
                    } else {
                        vm.message = 'Enter valid activation key.';
                        vm.status = 'error';
                        vm.loading = false;
                    }
                } else {
                    vm.$http.post(stm_lms_ajaxurl + '?action=stm_lms_login&nonce=' + stm_lms_nonces['stm_lms_login'], data).then(function (response) {

                        vm.message = response.body['message'];
                        vm.status = response.body['status'];
                        vm.loading = false;

                        if (response.body['user_page']) {
                            if (redirect) {
                                window.location = response.body['user_page'];
                            } else {
                                location.reload();
                            }
                        }
                    })
                }

            },
            lostPassword() {
                var vm = this;

                if (!(vm.lost_password.length)) return true;

                vm.lost_password_process = true;
                vm.message = '';
                var data = {
                    'user_login': vm.lost_password,
                };
                this.$http.post(stm_lms_ajaxurl + '?action=stm_lms_lost_password&nonce=' + stm_lms_nonces['stm_lms_lost_password'], data).then(function (response) {
                    vm.message = response.body['message'];
                    vm.status = response.body['status'];
                    vm.lost_password_process = false;
                });
            },
        }
    };

    new Vue(vue_obj);
    var app = new Vue({
        el: '#app',
        data: {
            visible: true
        }
    });
});
};
(function ($) {
$(window).load(function () {
    stm_lms_register(true);
})
})(jQuery);

function stm_lms_register(redirect) {
var $ = jQuery;
$('.stm-lms-register:not(.loaded)').each(function () {
    let $this = $(this);
    $(this).addClass('loaded');
    var vue_obj = {
        el: this,
        data: function () {
            return {
                vue_loaded: true,
                loading: false,
                phone: '',
                email: '',
                password: '',
                password_re: '',
                message: '',
                status: '',
                site_key: '',
                become_instructor: '',
                degree: '',
                expertize: '',
                recaptcha: '',
                captcha_error: '',
                privacy_policy: true,
                has_privacy_policy: false,
                choose_auditory: false,
                auditory: ''
            }
        },
        methods: {
            hasPrivacyPolicy() {
                if (!this.has_privacy_policy) {
                    this.has_privacy_policy = true;
                    this.privacy_policy = false;
                }
            },
            register() {
                var vm = this;
                vm.loading = true;
                vm.message = '';

                var data = {
                    'user_login': vm.email.split("@")[0],
                    'user_email': vm.email,
                    'user_phone': vm.phone,
                    'user_password': vm.password,
                    'user_password_re': vm.password_re,
                    'become_instructor': vm.become_instructor,
                    'privacy_policy': vm.privacy_policy,
                    'degree': vm.degree,
                    'expertize': vm.expertize,
                    'auditory': vm.auditory
                };

                    vm.processRegister(data);
                
            },
            processRegister(data) {

                var vm = this;

                this.$http.post(stm_lms_ajaxurl + '?action=stm_lms_register&nonce=' + stm_lms_nonces['stm_lms_register'], data).then(function (response) {
                    vm.message = response.body['message'];
                    //vm.status = response.body['status'];
                    vm.loading = false;
                    if (!vm.free) {
                        if (response.body['user_page']) {
                            if (redirect) {
                                window.location = response.body['user_page'];
                            } else {
                                location.reload();
                            }
                        }
                    } else {
                        if (vm.status == 'success') {
                            function closePopupOnFreeLessonPage() {
                                $('.pop-up').css('display', 'none');
                                $('html').css('overflow-y', 'scroll');
                                $('video').off('timeupdate');
                                $('video').trigger('play');
                            }
                            setTimeout(closePopupOnFreeLessonPage, 3000);
                            $('video').on('timeupdate', (e) => {
                                let currentTime = e.target.currentTime;
                                let duration = e.target.duration;
                                if (currentTime >= duration) {
                                    $('.next-video').css('display', 'flex');
                                }
                            })
                        }
                    }
                });
            }
        }
    };
    new Vue(vue_obj);
    var app = new Vue({
        el: '#app',
        data: {
            visible: true
        }
    });
});
};
      </script>


   <script>

function slideNumber(number) {
    $("#slider-range-min").slider('value', number);
    $('.slide-day').removeClass('sd-active');
    $('.day').removeClass('day-active');
    $('.slide-d' + number).addClass('sd-active');
    $('.day' + number).addClass('day-active');
}
$('.day1').click(function() {
    slideNumber(1);
})
$('.day2').click(function() {
    slideNumber(2);
})
$('.day3').click(function() {
    slideNumber(3);
})
$('.day4').click(function() {
    slideNumber(4);
})
$('.day5').click(function() {
    slideNumber(5);
})
$("#slider-range-min").slider({
    slide: function(event, ui) {
        slidervalue = ui.value;
        $('#slider-value').html(slidervalue);
        if (slidervalue == 1) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d1').addClass('sd-active');
            $('.day1').addClass('day-active');
        } else if (slidervalue == 2) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d2').addClass('sd-active');
            $('.day2').addClass('day-active');
        } else if (slidervalue == 3) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d3').addClass('sd-active');
            $('.day3').addClass('day-active');
        } else if (slidervalue == 4) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d4').addClass('sd-active');
            $('.day4').addClass('day-active');
        } else if (slidervalue == 5) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d5').addClass('sd-active');
            $('.day5').addClass('day-active');
        } else if (slidervalue == 6) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d6').addClass('sd-active');
            $('.day6').addClass('day-active');
        } else if (slidervalue == 7) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d7').addClass('sd-active');
            $('.day7').addClass('day-active');
        }
    }
});

if ($("#slider-range-min").length) {
    $("#slider-range-min").slider({
        range: "min",
        value: 1,
        min: 1,
        max: 5,
        paddingMin: 0,
        paddingMax: 50,
    });
}
</script>

<section class="pop-up-webinar">
   <button class="close-pop-webinar" onclick="$('#video-webinar').get(0).pause()">X</button>
   <div class="container">
      <div id="slick-4">
         <div class="pop-item">
            <div class="">
               <div class="webinar-video">
                  <div class="video-wrapper">
                     <video id="video-webinar" controls="" controlslist="nodownload">
                        <source src="<?php echo get_stylesheet_directory_uri();?>/video/4dfb1b06-lisa-final-1080px.mp4" type="video/mp4">
                     </video>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>


<!--<script type='text/javascript' src='js/slick.js'></script>-->
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js'></script>
<script>


$('#ndg-mobile-menu-activator').click(function() {
    $('#ndg-mobi-nav').show();
});
$('#ndg-mobi-close, .ndg-mobile-menu a').click(function() {
    $('#ndg-mobi-nav').hide(100);
});
$('#slick-1').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    dots: true,
    arrows: false,
    touchThreshold: 100
});
$('#slick-2').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    arrows: true,
    draggable: false,
    responsive: [{
        breakpoint: 1130,
        settings: {
            slidesToShow: 3,
            touchThreshold: 100,
            draggable: true
        }
    }, {
        breakpoint: 780,
        settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            touchThreshold: 100,
            autoplay: true,
            arrows: false
        }
    }, {
        breakpoint: 420,
        settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            touchThreshold: 100,
            autoplay: false,
            arrows: false
        }
    }]
});
$('#slick-3').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    touchThreshold: 100,
    arrows: false,
    dots: true
});
$('#slick-3').on('beforeChange', function(event, slick, currentSlide, nextSlide) {
    $('video').get(0).pause();
    cur = '#video-' + currentSlide;
    ide = '#video-' + nextSlide;
    $(cur).get(0).pause();
    console.log(ide);
    console.log(cur);
    $(ide).get(0).play();
    $('.playbt').hide();
    $('.pausebt').show();
});
$('.play').click(function() {
    $('.blur').addClass('body-blur');
    $('body').css('overflow-y', 'hidden');
});
$('.close-pop-stories').click(function() {
    $('.blur').removeClass('body-blur');
    $('body').css('overflow-y', 'auto');
    $('.pop-up-stories').css('left', '-1000vw');
    $('body,html').removeClass('hide-scroll')
});
$('.close-pop-webinar').click(function() {
   console.log('123');
    $('.blur').removeClass('body-blur');
    $('body').css('overflow-y', 'auto');
    $('.pop-up-webinar').css('left', '-1000vw');
    $('body,html').removeClass('hide-scroll')
});
$('.pausebt').click(function() {
    $('.pausebt').hide();
    $('.playbt').show();
});
$('.playbt').click(function() {
    $('.playbt').hide();
    $('.pausebt').show();
});
$('#slick-4').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    dots: true,
    fade: true,
    autoplay: true,
    autoplaySpeed: 3000,
    adaptiveHeight: true
});
$('#slick-5').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    arrows: true,
    draggable: false,
    responsive: [{
        breakpoint: 1130,
        settings: {
            slidesToShow: 3,
            touchThreshold: 100
        }
    }, {
        breakpoint: 780,
        settings: {
            slidesToShow: 3,
            slidesToScroll: 2,
            touchThreshold: 100,
            arrows: false
        }
    }, {
        breakpoint: 501,
        settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            touchThreshold: 100,
            arrows: false
        }
    }]
});

document.getElementById('video-0').addEventListener('ended',myHandler,false);
                            function myHandler(e) {
                                if(jQuery('video').is('#video-1')) {
                                    jQuery('#slick-3 ').slick('slickGoTo', 1, false);
                                    jQuery('#video-1').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }
                                else {
                                    jQuery('#slick-3 ').slick('slickGoTo', 0, false);
                                    jQuery('#video-0').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }

                            }
                            jQuery(document).ready(function(){
                                var controls = {
                                    video: jQuery("#video-0"),
                                    total: jQuery("#total-0"),
                                    progress: jQuery("#current-0"),
                                    hasHours: false
                                };
                                var video = controls.video[0];
                                video.addEventListener("timeupdate", function() {
                                    var progress = Math.floor(video.currentTime) / Math.floor(video.duration);
                                    controls.progress[0].style.width = Math.floor(progress * controls.total.width()) + "px";
                                }, false);
                            });;
document.getElementById('video-1').addEventListener('ended',myHandler,false);
                            function myHandler(e) {
                                if(jQuery('video').is('#video-2')) {
                                    jQuery('#slick-3 ').slick('slickGoTo', 2, false);
                                    jQuery('#video-2').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }
                                else {
                                    jQuery('#slick-3 ').slick('slickGoTo', 0, false);
                                    jQuery('#video-0').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }

                            }
                            jQuery(document).ready(function(){
                                var controls = {
                                    video: jQuery("#video-1"),
                                    total: jQuery("#total-1"),
                                    progress: jQuery("#current-1"),
                                    hasHours: false
                                };
                                var video = controls.video[0];
                                video.addEventListener("timeupdate", function() {
                                    var progress = Math.floor(video.currentTime) / Math.floor(video.duration);
                                    controls.progress[0].style.width = Math.floor(progress * controls.total.width()) + "px";
                                }, false);
                            });;
document.getElementById('video-2').addEventListener('ended',myHandler,false);
                            function myHandler(e) {
                                if(jQuery('video').is('#video-3')) {
                                    jQuery('#slick-3 ').slick('slickGoTo', 3, false);
                                    jQuery('#video-3').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }
                                else {
                                    jQuery('#slick-3 ').slick('slickGoTo', 0, false);
                                    jQuery('#video-0').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }

                            }
                            jQuery(document).ready(function(){
                                var controls = {
                                    video: jQuery("#video-2"),
                                    total: jQuery("#total-2"),
                                    progress: jQuery("#current-2"),
                                    hasHours: false
                                };
                                var video = controls.video[0];
                                video.addEventListener("timeupdate", function() {
                                    var progress = Math.floor(video.currentTime) / Math.floor(video.duration);
                                    controls.progress[0].style.width = Math.floor(progress * controls.total.width()) + "px";
                                }, false);
                            });;
document.getElementById('video-3').addEventListener('ended',myHandler,false);
                            function myHandler(e) {
                                if(jQuery('video').is('#video-4')) {
                                    jQuery('#slick-3 ').slick('slickGoTo', 4, false);
                                    jQuery('#video-4').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }
                                else {
                                    jQuery('#slick-3 ').slick('slickGoTo', 0, false);
                                    jQuery('#video-0').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }

                            }
                            jQuery(document).ready(function(){
                                var controls = {
                                    video: jQuery("#video-3"),
                                    total: jQuery("#total-3"),
                                    progress: jQuery("#current-3"),
                                    hasHours: false
                                };
                                var video = controls.video[0];
                                video.addEventListener("timeupdate", function() {
                                    var progress = Math.floor(video.currentTime) / Math.floor(video.duration);
                                    controls.progress[0].style.width = Math.floor(progress * controls.total.width()) + "px";
                                }, false);
                            });;
document.getElementById('video-4').addEventListener('ended',myHandler,false);
                            function myHandler(e) {
                                if(jQuery('video').is('#video-5')) {
                                    jQuery('#slick-3 ').slick('slickGoTo', 5, false);
                                    jQuery('#video-5').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }
                                else {
                                    jQuery('#slick-3 ').slick('slickGoTo', 0, false);
                                    jQuery('#video-0').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }

                            }
                            jQuery(document).ready(function(){
                                var controls = {
                                    video: jQuery("#video-4"),
                                    total: jQuery("#total-4"),
                                    progress: jQuery("#current-4"),
                                    hasHours: false
                                };
                                var video = controls.video[0];
                                video.addEventListener("timeupdate", function() {
                                    var progress = Math.floor(video.currentTime) / Math.floor(video.duration);
                                    controls.progress[0].style.width = Math.floor(progress * controls.total.width()) + "px";
                                }, false);
                            });;

</script>
   

</html>