<div id="header" class="transparent_header_off" data-color="">
    <div class="header_default ndg-header container header_2">
        <!-- navi -->
        <!-- test push -->
        <div class="container" style="margin-top: 20px;">
            <div class="row">
                <div class="col-md-12">
                    <div class="header_top">
                        <div class="logo-unit"> <a href="<?php echo home_url(); ?>"> <img class="img-responsive logo_transparent_static visible" src="<?php echo get_stylesheet_directory_uri();?>/img/bf185729-logo-main.svg" style="width: 229px" alt="ReBloom"/> </a></div>
                        <div class="cart-icon__wrapper mobile"> <a href="<?php echo home_url();?>/cart/"><img src="<?php echo get_stylesheet_directory_uri();?>/img/Cart.svg"></a></div>
                        <div class="right-unit">
                            ﻿ <a href="<?php the_permalink(45);?>" style="color:#224d3a;">Blog làm đẹp</a> <a href="<?php echo home_url();?>/#my-courses" class="btn stm_lms_account_popup__list_single orange-fill text-center" style="display: flex; margin-bottom: 0;">Các khóa học</a>
                            <div class="login">


                                <?php
                                if ( is_user_logged_in() ) {
                                    $user_info = $user_id ? new WP_User( $user_id ) : wp_get_current_user();
                                    ?>

                                    <div class="stm_lms_account_dropdown">
                                        <div class="dropdown">

                                            <button id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <?php if ( $user_info->first_name != null && $user_info->last_name != null ) { ?>
                                                    <span class="login_name"><?php echo 'Hey, '  . $user_info->first_name . ' ' . $user_info->last_name;	?></span>
                                                <?php } else { ?>
                                                    <span class="login_name"><?php echo 'Hey, '  . $user_info->user_login; ?></span>
                                                <?php } ?>
                                                <span class="caret"></span>
                                            </button>

                                            <ul class="dropdown-menu" aria-labelledby="dLabel">
                                                <li>
                                                    <a href="<?php echo esc_url(STM_LMS_User::user_page_url()); ?>">Account</a>
                                                    <a href="<?php echo wp_logout_url( home_url() ); ?>" class="stm_lms_logout">Logout</a>
                                                </li>
                                            </ul>

                                        </div>
                                    </div>

                                <?php } else {?>
                                    <a class="btn btn-default btn-login" data-text="Sign in"> Sign Up </a>
                                <?php }
                                ?>
                                <?php
                                stm_lms_register_style('register');
                                enqueue_register_script();
                                
                                include 'loginContainer.php';

                                global $woocommerce;?>
                            </div>
                            <div class="cart-icon__wrapper"> <span><?php echo WC()->cart->get_cart_contents_count(); ?></span> <a href="<?php echo wc_get_cart_url(); ?>"><img src="<?php echo get_stylesheet_directory_uri();?>/img/Cart.svg"></a></div>
                            <div class="phone">
                                <a class="phone__desktop">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50">
                                        <g id="Group_694" data-name="Group 694" transform="translate(-1129 -61)">
                                            <circle id="Ellipse_66" data-name="Ellipse 66" cx="25" cy="25" r="25" transform="translate(1129 61)" fill="#ff8667"/>
                                            <path id="Icon_metro-phone" data-name="Icon metro-phone" d="M20.926,18.874c-1.669,1.669-1.669,3.337-3.337,3.337s-3.337-1.669-5.006-3.337-3.337-3.337-3.337-5.006,1.669-1.669,3.337-3.337S9.245,3.856,7.577,3.856,2.571,8.862,2.571,8.862c0,3.337,3.429,10.1,6.675,13.349s10.012,6.675,13.349,6.675c0,0,5.006-3.337,5.006-5.006S22.594,17.205,20.926,18.874Z" transform="translate(1139.429 70.144)" fill="#fff"/>
                                        </g>
                                    </svg>
                                </a>
                                <div class="phone__form" id="phone__form">
                                    <div class="phone__form_text">
                                        <h5>Need help?</h5>
                                        <p>We will call you within 5 minutes and answer any questions about this course.</p>
                                    </div>
                                    <div class="phone__form_inputs" id="phone_form"> <input class="form-control" type="text" name="customer_name" placeholder="YOUR NAME"> <input class="form-control" type="tel" name="customer_phone" placeholder="PHONE NUMBER"> <a class="phone__form_btn send_email btn btn-default">CALL ME</a> <span id="phone_form__error" style="color: red;"> All fields must be filled </span></div>
                                    <span class="close_phone__form"> <img src="<?php echo get_stylesheet_directory_uri();?>/img/Close.svg"> </span>
                                </div>
                            </div>
                        </div>
                        <div class="stm_header_top_search sbc"> <i class="lnr lnr-magnifier"></i></div>
                        <!-- mobile -->
                        <?php do_action('wpml_add_language_selector');?>
                        <!-- mobile -->
                        <div class="stm_header_top_toggler mbc"> <i class="lnr lnr-menu"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="stm_lms_account_popup">
            <div class="stm_lms_account_popup__close"> <i class="lnr lnr-cross"></i></div>
            <div class="inner">
                <div class="stm_lms_account__head"> <a href="index.php"> <img class="img-responsive logo_transparent_static visible" src="<?php echo get_stylesheet_directory_uri();?>/img/bf185729-logo-main.svg" style="width: 229px" alt="ReBloom"/> </a> <a href="tel: +842873050007" class="phone__mobile"> <img src="<?php echo get_stylesheet_directory_uri();?>/img/Phone.svg"> </a></div>
                <div class="login_mobile">
                    <a class="btn btn-default btn-login" data-text="Sign in"> Sign Up </a>
                    <?php include 'loginContainer.php';?>
                </div>
                <div class="stm_lms_account_popup__list heading_font">
                    <a class="stm_lms_account_popup__list_single" href="<?php echo home_url();?>"> HOME </a> <a class="stm_lms_account_popup__list_single" href="#"> MAGAZINE </a> <a class="stm_lms_account_popup__list_single" href="<?php echo home_url();?>#my-courses"> COURSES </a>
                    <p class="stm_lms_account_popup__text"> ReBloom là khóa học online độc đáo đầu tiên tại Việt Nam về phương pháp mát xa mặt giúp đảo ngược quá trình lão hóa, dựa trên phương pháp Trẻ Hóa Sâu (Deep Rejuvenation Techniques – DRT) tác động đến các nhóm cơ và cơ quan nằm sâu dưới da. ReBloom hướng dẫn bạn những kiến thức và kĩ thuật mát xa đơn giản nhưng hiệu quả để bạn có thể áp dụng lâu dài.</p>
                    <div class="cart-icon__wrapper"> <a href="<?php echo get_stylesheet_directory_uri();?>/cart/"><img src="<?php echo get_stylesheet_directory_uri();?>/img/Cart.svg"></a></div>
                </div>
            </div>
        </div>


        <div class="stm_lms_menu_popup">
            <div class="stm_lms_menu_popup__close"> <i class="lnr lnr-cross"></i></div>
            <div class="inner">
                <h2>Menu</h2>
                <div class="stm_menu_toggler" data-text="Menu"></div>
                <div class="header_main_menu_wrapper clearfix" style="margin-top:5px;">
                    <div class="collapse navbar-collapse pull-right">
                        <ul class="header-menu clearfix"></ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.hidden {
    display: none;
}
</style>
<script>
jQuery('.submit_login_form').on("mousedown",function(){jQuery(this).css({'outline': 'none', 'box-shadow': 'inset 0 6px 7px 0px #00000040'})});
jQuery(document).on('mouseup',function(){jQuery(".submit_login_form").css({"box-shadow":"none"})});
jQuery(".login__form-register form").submit(function () {
    var $_this = jQuery(this);
    
    $.ajax("/wp-content/themes/masterstudy-child/registration_form.php",{
        method: "POST",
        data: $_this.serialize(),
        success: (data)=>{
            var obj = jQuery.parseJSON(data);
            if(obj.status){
                if($_this.hasClass('login_form_registration')) {
                    $_this.siblings().css({"display": "block"});
                    $_this.siblings().find(".success_message").text(obj.message);
                    $_this.siblings().find(".success_message").css({"display": "block"});
                    $_this.css({"display": "none"});
                }
                else if($_this.hasClass('login_form_code')){
                    $_this.find(".success_message").text(obj.message);
                    jQuery(".success_message").css({"display":"block"});
                    jQuery(".error_message").css({"display":"none"});
                    <?php $protocol = stripos($_SERVER['SERVER_PROTOCOL'],'https') === 0 ? 'https://' : 'http://';
                    $nameOfServer = $_SERVER['HTTP_HOST']; ?>
                    var url = "<?php echo $protocol . $nameOfServer ?>/members/"+obj.login;
                    $(location).attr('href',url);
                }
            }
            else if(!obj.status){
                $(".success_message").css({"display": "none"});
                $_this.find(".error_message").text(obj.error);
                $_this.find(".error_message").css({"display":"block"});
            }
            
        },error: (xhr, ajaxOptions, thrownError)=> {
            alert(xhr.status);
            alert(thrownError);
        }
    });
    return false;
});

    jQuery(function($) {

      // lostPassword script

        $(document).on('click', '#regChanger', function(event) {
          // hide and display inputs
            document.getElementById('regByPhone').classList.toggle('hidden');
            document.getElementById('regByEmail').classList.toggle('hidden');

        // text toggle
          backToLoginTEXT = "REGISTER BY PHONE"

            if ( document.getElementById('regChanger').innerText == backToLoginTEXT ) {
                document.getElementById('regChanger').innerHTML = "REGISTER BY EMAIL";
            } else {
                document.getElementById('regChanger').innerHTML = backToLoginTEXT;
            }

        });
        
        function mo_openid_on_consent_change(checkbox){
            if (! checkbox.checked) {
                jQuery('#mo_openid_consent_checkbox').val(1);
                jQuery(".btn-mo").attr("disabled", true);
                jQuery(".login-button").addClass("dis");
            } else {
                jQuery('#mo_openid_consent_checkbox').val(0);
                jQuery(".btn-mo").attr("disabled", false);
                jQuery(".login-button").removeClass("dis");
            }
        }

        var perfEntries = performance.getEntriesByType("navigation");

        if (perfEntries[0].type === "back_forward") {
            location.reload(true);
        }
        function HandlePopupResult(result) {
            window.location = "index.php";
        }
        function moOpenIdLogin(app_name,is_custom_app) {
            var current_url = window.location.href;
            var cookie_name = "redirect_current_url";
            var d = new Date();
            d.setTime(d.getTime() + (2 * 24 * 60 * 60 * 1000));
            var expires = "expires="+d.toUTCString();
            document.cookie = cookie_name + "=" + current_url + ";" + expires + ";path=/";

            var base_url = 'index.php';
            var request_uri = 'index.php';
            var http = '<?php echo get_stylesheet_directory_uri();?>/img/Cart.svg';
            var http_host = 'rebloom.vn';
            var default_nonce = '6c2cd05934';
            var custom_nonce = 'c4c8187ff8';

            if(is_custom_app == 'false'){
                if ( request_uri.indexOf('wp-login.php') !=-1){
                    var redirect_url = base_url + '/?option=getmosociallogin&wp_nonce=' + default_nonce + '&app_name=';

                }else {
                    var redirect_url = http + http_host + request_uri;
                    if(redirect_url.indexOf('?') != -1){
                        redirect_url = redirect_url +'&option=getmosociallogin&wp_nonce=' + default_nonce + '&app_name=';
                    }
                    else
                    {
                        redirect_url = redirect_url +'?option=getmosociallogin&wp_nonce=' + default_nonce + '&app_name=';
                    }
                }
            }
            else {
                if ( request_uri.indexOf('wp-login.php') !=-1){
                    var redirect_url = base_url + '/?option=oauthredirect&wp_nonce=' + custom_nonce + '&app_name=';


                }else {
                    var redirect_url = http + http_host + request_uri;
                    if(redirect_url.indexOf('?') != -1)
                        redirect_url = redirect_url +'&option=oauthredirect&wp_nonce=' + custom_nonce + '&app_name=';
                    else
                        redirect_url = redirect_url +'?option=oauthredirect&wp_nonce=' + custom_nonce + '&app_name=';
                }

            }
            if( 0) {
                var myWindow = window.open(redirect_url + app_name, "", "width=700,height=620");
            }
            else{
                window.location.href = redirect_url + app_name;
            }
        }
            
      // ajax when submit form
        $(document).on('click', '#regByMailSubmit', function(event) {
            event.preventDefault();

        // set form datas
            let email = $('input[name="enter_mail"]').val();
        
            let formData = new FormData();
            formData.append('emailToSend', email);

            $.ajax({
            url: '/wp-content/themes/masterstudy-child/regByMail_sendMail.php',
            type: 'POST',
            dataType: 'json',
            processData: false,
            contentType: false,
            cache: false,
            data: formData,
            success (data) {

            // if user logged in
                if (data.status) {
                    $('#regByMailerrorText').html(data.message);
                    $('#regByMailerrorText').css('color', "darkgreen");
                    //$('#regByMailSubmit').attr("disabled", true);
                } else {
                    $('#regByMailerrorText').html(data.error);
                    $('#regByMailerrorText').css('color', "crimson");
                }

            }
        });

        });

    }); 
</script>