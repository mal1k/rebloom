<footer id="footer">
         <div class="footer_wrapper ">
            <div id="footer_bottom">
               <div class="footer_widgets_wrapper kek text-upper">
                  <div class="container">
                     <div class="widgets cols_4 clearfix">
                        <aside id="custom_html-4" class="widget_text widget widget_custom_html">
                           <div class="textwidget custom-html-widget">
                              <img src="<?php echo get_stylesheet_directory_uri();?>/img/c4deb285-logo-footer.svg"
                                 style="width:150px;">
                              <?php if ( is_active_sidebar( 'footer-side-bar' ) ) : ?>
                                    <?php dynamic_sidebar( 'footer-side-bar' ); ?>
                                <?php endif; ?>
                              <div class="footer-copyright">
                                 <p>Copyright© 2019 ReBloom <?php echo date('Y');?></p>
                              </div>
                              <a href="#" target="_blank"><img src="<?php echo get_stylesheet_directory_uri();?>/img/gov_sticker.png"></a>
                           </div>
                        </aside>
                        <aside id="custom_html-3" class="widget_text widget widget_custom_html">
                           <div class="widget_title">
                              <h3>TRANG</h3>
                           </div>
                           <div class="textwidget custom-html-widget">

                           <?php if( $menu_items = wp_get_nav_menu_items('Footer 1') ) { 
                                    $menu_list = '';
                                    foreach ( (array) $menu_items as $key => $menu_item ) {
                                        $title = $menu_item->title; 
                                        $url = $menu_item->url; 
                                        $menu_list .= '<p> <a class="links-footer" href="' . $url . '">' . $title . '</a></p> ';
                                    }
                                    echo $menu_list;
                                }?>
                           </div>
                        </aside>
                        <aside id="custom_html-7" class="widget_text widget widget_custom_html">
                           <div class="textwidget custom-html-widget">
                              <div class="footer-contacts flex-col">
                                 <div class="footer-mail">
                                    <h5>LIÊN HỆ</h5>
                                    <p style="display: flex; align-items: center;"><img src="<?php echo get_stylesheet_directory_uri();?>/img/b183cf8e-email.svg"
                                       class="custom-logo" alt="Email"><a
                                       href="mailto:info@rebloom.vn">info@rebloom.vn</a></p>
                                 </div>
                                 <div class="footer-social-links flex-col">
                                    <h5>MẠNG XÃ HỘI</h5>
                                    <div> <a href="https://www.instagram.com/rebloom.vietnam"><img
                                       src="<?php echo get_stylesheet_directory_uri();?>/img/69f7f0af-insta.svg"
                                       alt="Instagram"></a> <a href="https://www.facebook.com/rebloomvietnam"><img
                                       src="<?php echo get_stylesheet_directory_uri();?>/img/cca25910-fb.svg"
                                       alt="Facebook"></a> <a href="https://www.youtube.com/channel/UCK7E024yhmMHaiQCJCW7u9Q"> <img src="<?php echo get_stylesheet_directory_uri();?>/img/eaf5cfe2-youtube.svg" alt="Youtube"></a></div>
                                 </div>
                              </div>
                           </div>
                        </aside>
                        <aside id="custom_html-6" class="widget_text widget widget_custom_html">
                           <div class="textwidget custom-html-widget">
                              <div class="footer-contacts">
                                 <h5> BÀI HỌC</h5>
                              </div>
                               <?php
                              $user_id = get_current_user_id();
            $current_user= wp_get_current_user();
            $customer_email = $current_user->email;
            $args = array(
                'post_type' => 'stm-courses',
                'posts_per_page' => 12
                );
            $orderIds = $wpdb->get_results("SELECT post_id FROM rebloom_postmeta WHERE meta_value = $user_id AND meta_key = '_customer_user'");

            if ($orderIds == null) {
                echo __( 'No courses' );
            }

            foreach ($orderIds as $orderId) {
                $orderArray[] = $orderId->post_id;
            }

            $postIds = $wpdb->get_results("SELECT * FROM rebloom_posts WHERE post_type = 'stm-courses' LIMIT 4");
                
            foreach ($postIds as $postId) : ?>

            <p><a class="links-footer" href="<?php echo $postId->guid; ?>"><?php echo $postId->post_title; ?></a></p>

            <?php endforeach; ?>

            <div class="footer-blog">
                <a href="<?php the_permalink(45)?>">
                <h5>Tạp chí <img src="<?php echo get_stylesheet_directory_uri();?>/img/349e1a88-arrow.svg"
                    class="custom-logo" alt="Arrow"></h5>
                </a>
            </div>
        </div>
        </aside>
        <div class="top-slice-arrow"> <a href="#" class="top-slice-arrow-a" style="opacity: 1;"></a></div>
        </div>
        </div>
    </div>
</div>
            <!-- Pop-up before go to cart -->
            <div class="buy-popup__wrapper">
               <div class="buy-popup__background"></div>
               <div class="buy-popup__main">
                  <img src="<?php echo get_stylesheet_directory_uri();?>/img/Course-Cover.png">
                  <div class="buy-popup__text">
                     <h5>Khóa học Trẻ Hóa Sâu ReBloom</h5>
                     <p>Khóa học Trẻ Hóa Sâu ReBloom bao gồm:</p>
                     <ul>
                        <li>- Tài khoản cá nhân cho học viên</li>
                        <li>- Quyền truy cập trọn bộ 30 video bài học online</li>
                        <li>- Phụ đề và lồng tiếng Việt</li>
                        <li>- Hỗ trợ kĩ thuật</li>
                     </ul>
                     <div class="buy-popup__button"> <span>2.100.000 VND</span> <a href='#' class='text-center btn btn-default btn-checkout' style="font-weight: 500;">Go to cart and pay</a></div>
                  </div>
               </div>
            </div>
            <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri();?>/css/jquery-ui.css">
         </div>

      </footer>
      <!-- Searchform -->
      <div class="modal fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchModal">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-body heading_font">
                  <div class="search-title">Search</div>
                  <form role="search" method="get" id="searchform" action="<?php home_url();?>">
                     <div class="search-wrapper"> <input placeholder="Start typing here..." type="text" class="form-control search-input" value="" name="s" id="s" /> <button type="submit" class="search-submit" ><i class="fa fa-search"></i></button></div>
                  </form>
               </div>
            </div>
         </div>
      </div>

     
      <link rel='stylesheet' id='stm-header_mobile-account-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/themes/masterstudy/assets/css/vc_modules/header_mobile/account.css' type='text/css' media='all' />
      <link rel='stylesheet' id='stm-lms-login-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/uploads/stm_lms_styles/parts/login.css' type='text/css' media='all' />
      <link rel='stylesheet' id='stm-lms-register-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/uploads/stm_lms_styles/parts/register.css' type='text/css' media='all' />
      
      <link rel='stylesheet' id='stm-vue-autocomplete-vue2-autocomplete-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/themes/masterstudy/assets/css/vc_modules/vue-autocomplete/vue2-autocomplete.css' type='text/css' media='all' />
      <link rel='stylesheet' id='stm-lms-enterprise-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/uploads/stm_lms_styles/parts/enterprise.css' type='text/css' media='all' />
      <link rel='stylesheet' id='stm-lms-user-courses-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/uploads/stm_lms_styles/parts/user-courses.css' type='text/css' media='all' />
      <link rel='stylesheet' id='stm-lms-instructor_courses-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/uploads/stm_lms_styles/parts/instructor_courses.css' type='text/css' media='all' />
      <link rel='stylesheet' id='fv_flowplayer-css'  href='<?php echo get_stylesheet_directory_uri();?>/modules/fv-flowplayer-custom/style-1.css' type='text/css' media='all' />
      
      <div class="activate-pop-up">
         <div class="activate-pop-up__layout"></div>
         <div class="activate-pop-up__container">
            <label for="license_key" style="color:#000;">Activation key</label> <input class="form-control" type="text" id="license_key" placeholder="Enter activation key"> <button id="activate" class="btn btn-default text-center">Activate</button>
            <div class="active-pop-up__message"></div>
         </div>
      </div>
      <?php wp_footer();?>
   </body>
   <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
   
     
   <script type='text/javascript' src='<?php echo get_stylesheet_directory_uri();?>/js/lib.js'></script>
   
   <script>

function slideNumber(number) {
    $("#slider-range-min").slider('value', number);
    $('.slide-day').removeClass('sd-active');
    $('.day').removeClass('day-active');
    $('.slide-d' + number).addClass('sd-active');
    $('.day' + number).addClass('day-active');
}
$('.day1').click(function() {
    slideNumber(1);
})
$('.day2').click(function() {
    slideNumber(2);
})
$('.day3').click(function() {
    slideNumber(3);
})
$('.day4').click(function() {
    slideNumber(4);
})
$('.day5').click(function() {
    slideNumber(5);
})
$("#slider-range-min").slider({
    slide: function(event, ui) {
        slidervalue = ui.value;
        $('#slider-value').html(slidervalue);
        if (slidervalue == 1) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d1').addClass('sd-active');
            $('.day1').addClass('day-active');
        } else if (slidervalue == 2) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d2').addClass('sd-active');
            $('.day2').addClass('day-active');
        } else if (slidervalue == 3) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d3').addClass('sd-active');
            $('.day3').addClass('day-active');
        } else if (slidervalue == 4) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d4').addClass('sd-active');
            $('.day4').addClass('day-active');
        } else if (slidervalue == 5) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d5').addClass('sd-active');
            $('.day5').addClass('day-active');
        } else if (slidervalue == 6) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d6').addClass('sd-active');
            $('.day6').addClass('day-active');
        } else if (slidervalue == 7) {
            $('.slide-day').removeClass('sd-active');
            $('.day').removeClass('day-active');
            $('.slide-d7').addClass('sd-active');
            $('.day7').addClass('day-active');
        }
    }
});

if ($("#slider-range-min").length) {
    $("#slider-range-min").slider({
        range: "min",
        value: 1,
        min: 1,
        max: 5,
        paddingMin: 0,
        paddingMax: 50,
    });
}
</script>

<section class="pop-up-webinar">
   <button class="close-pop-webinar" onclick="$('#video-webinar').get(0).pause()">X</button>
   <div class="container">
      <div id="slick-4">
         <div class="pop-item">
            <div class="">
               <div class="webinar-video">
                  <div class="video-wrapper">
                     <video id="video-webinar" controls="" controlslist="nodownload">
                        <source src="<?php echo get_stylesheet_directory_uri();?>/video/4dfb1b06-lisa-final-1080px.mp4" type="video/mp4">
                     </video>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>

<!--upd-->

<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js'></script>
<script>
$(document).on('click', '#dLabel', function(){
   var state = $(this).closest('.dropdown');
   state.toggleClass('open');
})

$('#ndg-mobile-menu-activator').click(function() {
    $('#ndg-mobi-nav').show();
});
$('#ndg-mobi-close, .ndg-mobile-menu a').click(function() {
    $('#ndg-mobi-nav').hide(100);
});
$('#slick-1').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    dots: true,
    arrows: false,
    touchThreshold: 100
});
$('#slick-2').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    arrows: true,
    draggable: false,
    responsive: [{
        breakpoint: 1200,
        settings: {
            slidesToShow: 3,
            touchThreshold: 100,
            draggable: true
        }
    }, {
        breakpoint: 992,
        settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            touchThreshold: 100,
            autoplay: true,
        }
    }, {
        breakpoint: 576,
        settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            touchThreshold: 100,
            autoplay: false,
            autoplay: true,
        }
    }]
});
$('#slick-3').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    touchThreshold: 100,
    arrows: false,
    dots: true
});
$('#slick-3').on('beforeChange', function(event, slick, currentSlide, nextSlide) {
    $('video').get(0).pause();
    cur = '#video-' + currentSlide;
    ide = '#video-' + nextSlide;
    $(cur).get(0).pause();
    console.log(ide);
    console.log(cur);
    $(ide).get(0).play();
    $('.playbt').hide();
    $('.pausebt').show();
});
$('.play').click(function() {
    $('.blur').addClass('body-blur');
    $('body').css('overflow-y', 'hidden');
});
$('.close-pop-stories').click(function() {
    $('.blur').removeClass('body-blur');
    $('body').css('overflow-y', 'auto');
    $('.pop-up-stories').css('left', '-1000vw');
    $('body,html').removeClass('hide-scroll')
});
$('.close-pop-webinar').click(function() {
   console.log('123');
    $('.blur').removeClass('body-blur');
    $('body').css('overflow-y', 'auto');
    $('.pop-up-webinar').css('left', '-1000vw');
    $('body,html').removeClass('hide-scroll')
});
$('.pausebt').click(function() {
    $('.pausebt').hide();
    $('.playbt').show();
});
$('.playbt').click(function() {
    $('.playbt').hide();
    $('.pausebt').show();
});
$('#slick-4').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    dots: true,
    fade: true,
    autoplay: true,
    autoplaySpeed: 3000,
    adaptiveHeight: true
});
$('#slick-5').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    arrows: true,
    draggable: false,
    responsive: [{
        breakpoint: 1200,
        settings: {
            slidesToShow: 3,
            touchThreshold: 100,
            draggable: true
        }
    }, {
        breakpoint: 992,
        settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            touchThreshold: 100,
            autoplay: true,
        }
    }, {
        breakpoint: 576,
        settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            touchThreshold: 100,
            autoplay: false,
            autoplay: true,
        }
    }]
});

    
    
    (function ($) {
  $(document).ready(function () {
    $('.stm_lms_settings_button').on('click', function () {
      $('.stm-lms-user_edit_profile_btn').click();
    });
    $('.stm-lms-user-avatar-edit .delete_avatar').on('click', function () {
      var $this = $(this);
      var $parent = $this.closest('.stm-lms-user-avatar-edit');
      $parent.addClass('loading-avatar');
      var formData = new FormData();
      formData.append('action', 'stm_lms_delete_avatar');
      formData.append('nonce', stm_lms_nonces['stm_lms_delete_avatar']);
      $this.remove();
      $.ajax({
        url: stm_lms_ajaxurl,
        type: 'POST',
        data: formData,
        processData: false,
        // tell jQuery not to process the data
        contentType: false,
        // tell jQuery not to set contentType
        success: function success(data) {
          $parent.removeClass('loading-avatar');

          if (data.file) {
            $parent.find('img').remove();
            $parent.find('.stm-lms-user_avatar').append(data.file);
          }
        }
      });
    });
    $('.stm-lms-user-avatar-edit input').on('change', function () {
      var $this = $(this);
      var files = $this[0].files;
      var $parent = $this.closest('.stm-lms-user-avatar-edit');
      $parent.addClass('loading-avatar');

      if (files.length) {
        var file = files[0];
        var formData = new FormData();
        formData.append('file', file);
        formData.append('action', 'stm_lms_change_avatar');
        formData.append('nonce', stm_lms_nonces['stm_lms_change_avatar']);
        $.ajax({
          url: stm_lms_ajaxurl,
          type: 'POST',
          data: formData,
          processData: false,
          // tell jQuery not to process the data
          contentType: false,
          // tell jQuery not to set contentType
          success: function success(data) {
            $parent.removeClass('loading-avatar');

            if (data.file) {
              $parent.find('img').attr('src', data.file);
            }
          }
        });
      }
    });
    $('[data-container]').on('click', function (e) {
      e.preventDefault();
      var $default_container = $('[data-container-open=".stm_lms_private_information"]');
      var $container = $('[data-container-open="' + $(this).attr('data-container') + '"]');
      var container_visible = $container.is(':visible');
      /*Close all*/

      $('[data-container]').removeClass('active');
      $('[data-container-open]').slideUp();
      /*Open Current*/

      if (!container_visible) {
        $(this).addClass('active');
        $container.slideDown();
      } else {
        $default_container.slideDown();
      }
    }); // $('.stm-lms-user_edit_profile_btn').on('click', function(e){
    //     e.preventDefault();
    //     console.log($(this).is(':visible'));
    //     $(this).toggleClass('active');
    //
    //     $('.stm_lms_private_information, .stm_lms_edit_account').slideToggle();
    // });

    $('body').addClass('stm_lms_chat_page');
    new Vue({
      el: '#stm_lms_edit_account',
      data: function data() {
        return {
          data: stm_lms_edit_account_info,
          loading: false,
          message: '',
          status: 'error'
        };
      },
      methods: {
        saveUserInfo: function saveUserInfo() {
          var vm = this;
          var data = "&description=" + vm.data.meta['description'];
          data += "&facebook=" + vm.data.meta['facebook'];
          data += "&first_name=" + vm.data.meta['first_name'];
          data += "&last_name=" + vm.data.meta['last_name'];
          data += "&twitter=" + vm.data.meta['twitter'];
          data += "&instagram=" + vm.data.meta['instagram'];
          data += "&google-plus=" + vm.data.meta['google-plus'];
          data += "&position=" + vm.data.meta['position'];

          if (typeof vm.data.meta['new_pass'] !== 'undefined') {
            data += "&new_pass=" + vm.data.meta['new_pass'];
          }

          if (typeof vm.data.meta['new_pass_re'] !== 'undefined') {
            data += "&new_pass_re=" + vm.data.meta['new_pass_re'];
          }

          var url = stm_lms_ajaxurl + '?action=stm_lms_save_user_info' + data + '&nonce=' + stm_lms_nonces['stm_lms_save_user_info'];
          vm.loading = true;
          vm.message = vm.status = '';
          this.$http.get(url).then(function (response) {
            vm.loading = false;
            vm.message = response.body['message'];
            vm.status = response.body['status'];

            if (response.body['relogin']) {
              window.location.href = response.body['relogin'];
            } // update Data


            var data_fields = {
              'bio': '',
              'facebook': 'href',
              'twitter': 'href',
              'google-plus': 'href',
              'position': '',
              'first_name': '',
              'instagram': 'href'
            };

            for (var k in data_fields) {
              if (data_fields.hasOwnProperty(k)) {
                if (data_fields[k]) {
                  $('.stm_lms_update_field__' + k).attr(data_fields[k], vm.data['meta'][k]);
                } else {
                  $('.stm_lms_update_field__' + k).text(vm.data['meta'][k]);
                }
              }
            }
          });
        }
      }
    });
  });
})(jQuery);  
    
    
    
    
document.getElementById('video-0').addEventListener('ended',myHandler,false);
                            function myHandler(e) {
                                if(jQuery('video').is('#video-1')) {
                                    jQuery('#slick-3 ').slick('slickGoTo', 1, false);
                                    jQuery('#video-1').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }
                                else {
                                    jQuery('#slick-3 ').slick('slickGoTo', 0, false);
                                    jQuery('#video-0').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }

                            }
                            jQuery(document).ready(function(){
                                var controls = {
                                    video: jQuery("#video-0"),
                                    total: jQuery("#total-0"),
                                    progress: jQuery("#current-0"),
                                    hasHours: false
                                };
                                var video = controls.video[0];
                                video.addEventListener("timeupdate", function() {
                                    var progress = Math.floor(video.currentTime) / Math.floor(video.duration);
                                    controls.progress[0].style.width = Math.floor(progress * controls.total.width()) + "px";
                                }, false);
                            });;
document.getElementById('video-1').addEventListener('ended',myHandler,false);
                            function myHandler(e) {
                                if(jQuery('video').is('#video-2')) {
                                    jQuery('#slick-3 ').slick('slickGoTo', 2, false);
                                    jQuery('#video-2').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }
                                else {
                                    jQuery('#slick-3 ').slick('slickGoTo', 0, false);
                                    jQuery('#video-0').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }

                            }
                            jQuery(document).ready(function(){
                                var controls = {
                                    video: jQuery("#video-1"),
                                    total: jQuery("#total-1"),
                                    progress: jQuery("#current-1"),
                                    hasHours: false
                                };
                                var video = controls.video[0];
                                video.addEventListener("timeupdate", function() {
                                    var progress = Math.floor(video.currentTime) / Math.floor(video.duration);
                                    controls.progress[0].style.width = Math.floor(progress * controls.total.width()) + "px";
                                }, false);
                            });;
document.getElementById('video-2').addEventListener('ended',myHandler,false);
                            function myHandler(e) {
                                if(jQuery('video').is('#video-3')) {
                                    jQuery('#slick-3 ').slick('slickGoTo', 3, false);
                                    jQuery('#video-3').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }
                                else {
                                    jQuery('#slick-3 ').slick('slickGoTo', 0, false);
                                    jQuery('#video-0').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }

                            }
                            jQuery(document).ready(function(){
                                var controls = {
                                    video: jQuery("#video-2"),
                                    total: jQuery("#total-2"),
                                    progress: jQuery("#current-2"),
                                    hasHours: false
                                };
                                var video = controls.video[0];
                                video.addEventListener("timeupdate", function() {
                                    var progress = Math.floor(video.currentTime) / Math.floor(video.duration);
                                    controls.progress[0].style.width = Math.floor(progress * controls.total.width()) + "px";
                                }, false);
                            });;
document.getElementById('video-3').addEventListener('ended',myHandler,false);
                            function myHandler(e) {
                                if(jQuery('video').is('#video-4')) {
                                    jQuery('#slick-3 ').slick('slickGoTo', 4, false);
                                    jQuery('#video-4').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }
                                else {
                                    jQuery('#slick-3 ').slick('slickGoTo', 0, false);
                                    jQuery('#video-0').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }

                            }
                            jQuery(document).ready(function(){
                                var controls = {
                                    video: jQuery("#video-3"),
                                    total: jQuery("#total-3"),
                                    progress: jQuery("#current-3"),
                                    hasHours: false
                                };
                                var video = controls.video[0];
                                video.addEventListener("timeupdate", function() {
                                    var progress = Math.floor(video.currentTime) / Math.floor(video.duration);
                                    controls.progress[0].style.width = Math.floor(progress * controls.total.width()) + "px";
                                }, false);
                            });;
document.getElementById('video-4').addEventListener('ended',myHandler,false);
                            function myHandler(e) {
                                if(jQuery('video').is('#video-5')) {
                                    jQuery('#slick-3 ').slick('slickGoTo', 5, false);
                                    jQuery('#video-5').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }
                                else {
                                    jQuery('#slick-3 ').slick('slickGoTo', 0, false);
                                    jQuery('#video-0').get(0).play();
                                    jQuery('.playbt').hide();
                                    jQuery('.pausebt').show();
                                }

                            }
                            jQuery(document).ready(function(){
                                var controls = {
                                    video: jQuery("#video-4"),
                                    total: jQuery("#total-4"),
                                    progress: jQuery("#current-4"),
                                    hasHours: false
                                };
                                var video = controls.video[0];
                                video.addEventListener("timeupdate", function() {
                                    var progress = Math.floor(video.currentTime) / Math.floor(video.duration);
                                    controls.progress[0].style.width = Math.floor(progress * controls.total.width()) + "px";
                                }, false);
                            });;
    
    
  
    

</script>


</html>