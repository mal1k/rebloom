<?php
    require( '../../../wp-load.php' );
    session_start();

    if(!empty($_POST['enter_code'])){
        if($_POST['enter_code'] == $_SESSION['passOfRegMail']){
            $login = $_SESSION['registrationPhone'];
            $pass = $_SESSION['registrationPass'];
            $mail = $_SESSION['registrationMail'];
            $login = str_replace('+','',$login);
            if (!username_exists( $pass ) || !email_exists( $mail ) ) {
                $user_id = wp_create_user( $login, $pass, $mail );
                $user = new WP_User( $user_id );
                
                $creds['user_login'] = $login;
                $creds['user_password'] = $pass;
                $creds['remember'] = false;

                $user = wp_signon( $creds, false );

				$message = "Thank you for registration!";
                $message .= "\nYour login: ".$login;
                $message .= "\nYour password: ".$pass;

                wp_mail( $mail, 'Registration was successful', $message );

                $response = [
                    "status"  => true,
                    "message" => 'Successfully logged in. Redirecting...',
                    "login"   => $login
                    ];
                echo json_encode($response);
                exit;
            }
            else{
                $response = [
                    "status" => false,
                    "error" => 'The user exists',
                    ];
                echo json_encode($response);
                exit; 
            }
        }
        else{
            $response = [
                "status" => false,
                "error" => 'The code is not correct'
            ];
            echo json_encode($response);
            exit;
        }
    }
    
    else if(!empty($_POST['phoneToSend'] && $_POST['emailToSend'] && $_POST['passToSend'])){
        if (!filter_var($_POST['emailToSend'], FILTER_VALIDATE_EMAIL)){
            $response = [
                "status" => false,
                "error" => 'Incorrect email format'
            ];
            echo json_encode($response);
        exit;
        }

        $_SESSION['registrationPhone']= $_POST['phoneToSend'];
        $_SESSION['registrationPass'] = $_POST['passToSend'];
        $_SESSION['registrationMail'] = $_POST['emailToSend'];

        include 'regByMail_sendMail.php';
    }
    else{
        $response = [
            "status" => false,
            "error" => 'No data entered'
        ];
        echo json_encode($response);
    exit;
    }
    
?>