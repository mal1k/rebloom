<?php 

/**
* Template Name: Default Page
*
*/

get_header();?>


<div id="wrapper">
   <div class="lal"></div>
   <?php require_once("navi.php");?>
   <!-- id header -->
   <div id="main">
      <section class="container">
         <article id="post-2882" class="post-2882 page type-page status-publish hentry">
            <h1 class="about-course-header"><?php the_title()?></h1>
         </article>
      </section>
      <section class="photo-page-course">
         <div class="container">

         

            <img width="100%" class="img-agreement" src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full') ?>">
            <div class="agreement-text">
            <?php 
            if ( have_posts() ) {
               while ( have_posts() ) {
                  the_post(); 
                  the_content();
               }
            } 
            ?>
            </div>
         </div>
      </section>
   </div>
</div>

<?php get_footer();?>